<?php return array('dependencies' => array('jquery', 'react', 'react-dom', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n'), 'version' => '6350ee55714ffdff067b');
