</div> <!-- /.swiper-wrapper   -->

<?php if ($settings['slider_options']['arrowNavigation']) : ?>
	<span class="rtcl-gb-slider-btn button-left rtcl-icon-angle-left"></span>
	<span class="rtcl-gb-slider-btn button-right rtcl-icon-angle-right"></span>
<?php endif; ?>

<?php if ($settings['slider_options']['dotNavigation']) : ?>
	<div class="rtcl-gb-slider-pagination"></div>
<?php endif; ?>

</div>
</div>
</div>